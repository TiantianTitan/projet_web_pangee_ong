<!DOCTYPE html>
<html lang="fr-FR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Handi-capacités – Tous gagnants par l’exercice physique et mental</title>
    <link rel="stylesheet" href="./testphp/css/style.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        header, footer {
            background-color: #333;
            color: #fff;
        }
        header a, footer a {
            color: #fff;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
        .header-main, .footer-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }
        .header-main img {
            height: 60px;
        }
        .main-content {
            padding: 20px 0;
        }
        .main-content h1, .main-content h2, .main-content p {
            margin: 15px 0;
        }
        .iframe-container {
            margin: 20px 0;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .text-center {
            text-align: center;
        }
        .flex-row {
            display: flex;
            flex-wrap: wrap;
        }
        .flex-column {
            flex: 1;
            padding: 10px;
        }
        .flex-column.half {
            flex: 0 0 50%;
        }
        .flex-column.right {
            flex: 0 0 30%;
        }
        .bottom-widgets {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .iframe-large {
            flex: 0 0 70%;
        }
        iframe {
            width: 100%;
            border: none;
            overflow: hidden;
        }
        .team-photo {
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body id="top" class="home page-template-default page page-id-2 stretched rtl_columns av-curtain-numeric helvetica-websave helvetica  avia-responsive-images-support">
    <div id="wrap_all">
        <header>
            <div class="container">
                <div class="header-main">
                    <a href="https://handicapacites.org/">
                        <img src="./testphp/uploads/images/logo-HSCT.png" alt="Handi-capacités" title="logo-HSCT">
                    </a>
                    <nav class="main_menu" role="navigation">
                        <ul role="menu" class="menu av-main-nav" id="avia-menu">
                            <!-- Menu items -->
                        </ul>
                    </nav>
                </div>
            </div>
        </header>

        <div id="main" class="main-content">
            <div class="container">
                <section>
                <!-- New Section for Project Carriers -->

                    <h2 class="text-center">Porteurs du Projet</h2>
                    <p>Le Premier Congrès Mondial "HANDICAPACITES" est organisé par la <strong>Fondation Sanitus</strong>, le <strong>PANATHLON INTERNATIONAL DISTRICT FRANCE</strong>, et l'<strong>UNESCO</strong>. Cet événement pionnier vise à promouvoir l'inclusion des personnes handicapées dans les domaines du sport, de la santé et du travail.</p>
                    <p class="text-center">Ensemble, nous pouvons faire une différence. Soutenez-nous pour bâtir un monde plus inclusif et équitable. Merci de votre générosité !</p>

                    <div class="iframe-container">
                        <iframe id="haWidget1" allowtransparency="true" src="https://www.helloasso.com/associations/panathlon-international-district-france/evenements/premier-congres-mondial-handicapacites-du-9-9-2024/widget-bouton" style="height: 70px;"></iframe>
                    </div>
                    <div class="bottom-widgets">
                        <div class="iframe-container iframe-large">
                            <iframe id="haWidget3" allowtransparency="true" scrolling="auto" src="https://www.helloasso.com/associations/panathlon-international-district-france/collectes/don-pour-premier-congres-mondial-handicapacites/widget" style="height: 750px;"></iframe>
                        </div>
                        <div class="iframe-container right">
                            <iframe id="haWidget2" allowtransparency="true" scrolling="auto" src="https://www.helloasso.com/associations/panathlon-international-district-france/evenements/premier-congres-mondial-handicapacites-du-9-9-2024/widget-vignette" style="height: 750px;"></iframe>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <footer>
            <div class="container">
                <div class="footer-main">
                    <span>&copy; Handi-Capacités 2023</span>
                    <div>
                        <a href="https://handicapacites.org/mentions-legales" target="_blank" title="Mentions légales">Mentions légales</a> | 
                        <a href="http://www.leadleader.fr/" target="_blank" title="Lead Leader">Lead Leader</a> | 
                        <a href="https://ginsao.fr/creation-site-web-internet-reseaux-sociaux-creation-internet-94/" target="_blank" title="Création site Internet">Création site ginsao.fr</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script src="./testphp/js/jquery/jquery.min.js"></script>
    <script src="./testphp/js/jquery/jquery-migrate.min.js"></script>
    <script src="./testphp/js/mediaelement/mediaelement-and-player.min.js"></script>
    <script src="./testphp/js/mediaelement/mediaelement-migrate.min.js"></script>    
    <script src="./testphp/js/mediaelement/wp-mediaelement.min.js"></script>

</body>
</html>
